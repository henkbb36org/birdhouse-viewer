import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  devices: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return await db.getUserDevices(ctx.user.id);
    }),
    
    create: protectedProcedure
      .input(z.object({
        deviceId: z.string().min(1).max(64),
        name: z.string().min(1).max(255),
        description: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        // Check if device already exists
        const existing = await db.getDeviceByDeviceId(input.deviceId);
        if (existing) {
          throw new Error("Device ID already registered");
        }
        
        await db.createDevice({
          userId: ctx.user.id,
          deviceId: input.deviceId,
          name: input.name,
          description: input.description,
        });
        
        return { success: true };
      }),
    
    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ ctx, input }) => {
        const device = await db.getDeviceById(input.id);
        if (!device || device.userId !== ctx.user.id) {
          throw new Error("Device not found or unauthorized");
        }
        
        await db.deleteDevice(input.id);
        return { success: true };
      }),
    
    startStream: protectedProcedure
      .input(z.object({ deviceId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        const device = await db.getDeviceById(input.deviceId);
        if (!device || device.userId !== ctx.user.id) {
          throw new Error("Device not found or unauthorized");
        }
        
        // Check if there's already an active session
        const existingSession = await db.getActiveSession(input.deviceId, ctx.user.id);
        if (existingSession) {
          return { 
            success: true, 
            sessionId: existingSession.id,
            expiresAt: existingSession.expiresAt 
          };
        }
        
        // Create new session (60 seconds)
        const expiresAt = new Date(Date.now() + 60000);
        const result = await db.createSession({
          deviceId: input.deviceId,
          userId: ctx.user.id,
          expiresAt,
        });
        
        return { 
          success: true, 
          sessionId: result[0].insertId,
          expiresAt 
        };
      }),
    
    stopStream: protectedProcedure
      .input(z.object({ sessionId: z.number() }))
      .mutation(async ({ input }) => {
        await db.expireSession(input.sessionId);
        return { success: true };
      }),
  }),
  
  motion: router({
    getRecent: protectedProcedure
      .input(z.object({ deviceId: z.number(), limit: z.number().optional() }))
      .query(async ({ ctx, input }) => {
        const device = await db.getDeviceById(input.deviceId);
        if (!device || device.userId !== ctx.user.id) {
          throw new Error("Device not found or unauthorized");
        }
        
        return await db.getRecentMotionEvents(input.deviceId, input.limit);
      }),
  }),
});

export type AppRouter = typeof appRouter;
