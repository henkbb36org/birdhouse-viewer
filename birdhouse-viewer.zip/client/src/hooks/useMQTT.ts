import { useEffect, useRef, useState, useCallback } from 'react';
import mqtt, { MqttClient } from 'mqtt';

interface UseMQTTOptions {
  brokerUrl: string;
  username?: string;
  password?: string;
  onMessage?: (topic: string, message: Buffer) => void;
  onConnect?: () => void;
  onDisconnect?: () => void;
  onError?: (error: Error) => void;
}

export function useMQTT(options: UseMQTTOptions) {
  const [isConnected, setIsConnected] = useState(false);
  const [error, setError] = useState<Error | null>(null);
  const clientRef = useRef<MqttClient | null>(null);
  const subscribedTopicsRef = useRef<Set<string>>(new Set());

  useEffect(() => {
    // Connect to MQTT broker via WebSocket
    const client = mqtt.connect(options.brokerUrl, {
      username: options.username,
      password: options.password,
      protocol: 'ws',
      reconnectPeriod: 5000,
      connectTimeout: 30000,
    });

    clientRef.current = client;

    client.on('connect', () => {
      setIsConnected(true);
      setError(null);
      options.onConnect?.();
    });

    client.on('disconnect', () => {
      setIsConnected(false);
      options.onDisconnect?.();
    });

    client.on('error', (err) => {
      setError(err);
      options.onError?.(err);
    });

    client.on('message', (topic, message) => {
      options.onMessage?.(topic, message);
    });

    return () => {
      client.end();
      clientRef.current = null;
      subscribedTopicsRef.current.clear();
    };
  }, [options.brokerUrl, options.username, options.password]);

  const subscribe = useCallback((topic: string) => {
    if (clientRef.current && isConnected && !subscribedTopicsRef.current.has(topic)) {
      clientRef.current.subscribe(topic, (err) => {
        if (!err) {
          subscribedTopicsRef.current.add(topic);
        } else {
          console.error('Failed to subscribe to topic:', topic, err);
        }
      });
    }
  }, [isConnected]);

  const unsubscribe = useCallback((topic: string) => {
    if (clientRef.current && subscribedTopicsRef.current.has(topic)) {
      clientRef.current.unsubscribe(topic, (err) => {
        if (!err) {
          subscribedTopicsRef.current.delete(topic);
        } else {
          console.error('Failed to unsubscribe from topic:', topic, err);
        }
      });
    }
  }, []);

  const publish = useCallback((topic: string, message: string | Buffer) => {
    if (clientRef.current && isConnected) {
      clientRef.current.publish(topic, message, (err) => {
        if (err) {
          console.error('Failed to publish to topic:', topic, err);
        }
      });
    }
  }, [isConnected]);

  return {
    isConnected,
    error,
    subscribe,
    unsubscribe,
    publish,
  };
}
