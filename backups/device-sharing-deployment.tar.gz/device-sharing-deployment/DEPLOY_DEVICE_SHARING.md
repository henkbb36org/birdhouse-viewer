# Device Sharing Feature - Deployment Instructions

This package contains the device sharing feature for the Birdhouse Viewer application.

## What's New

**Device Sharing Feature** allows multiple users to access the same birdhouse device with individual Google accounts:

- **Email-based sharing** - Share devices by entering email addresses
- **Owner/Viewer roles** - Owners control sharing, viewers can watch streams
- **Shared notifications** - All users with access receive motion alerts
- **Owner/Viewer badges** - Visual indicators showing device ownership
- **Share management UI** - Dialog to add/remove shared users
- **Authorization updates** - Proper access control for all device operations

## Database Changes

⚠️ **IMPORTANT**: This update includes database schema changes that require migration.

### Schema Changes:
1. **Renamed column**: `devices.userId` → `devices.ownerId`
2. **New table**: `deviceShares` (junction table for many-to-many relationships)

### Migration Details:
- The migration will **rename** the `userId` column to `ownerId` (preserves existing data)
- A new `deviceShares` table will be created
- All existing devices remain owned by their original users
- No data loss occurs during migration

## Files Included

### Backend Files:
- `drizzle/schema.ts` - Updated schema with deviceShares table
- `server/db.ts` - New sharing queries and authorization helpers
- `server/routers.ts` - New sharing procedures (shareDevice, unshareDevice, getSharedUsers)
- `server/notifications.ts` - Updated to notify all users with device access
- `server/videoRoutes.ts` - Updated authorization for video access

### Frontend Files:
- `client/src/components/ShareDeviceDialog.tsx` - New share management dialog
- `client/src/pages/Devices.tsx` - Updated with share button and badges

### Documentation:
- `DEVICE_SHARING.md` - Complete feature documentation
- `DEPLOY_DEVICE_SHARING.md` - This file
- `deploy.sh` - Automated deployment script
- `rollback.sh` - Rollback script if needed

## Prerequisites

- Node.js v22.15.0 or higher
- pnpm package manager
- MySQL database
- Existing Birdhouse Viewer installation
- Backup of your database (recommended)

## Deployment Steps

### Option 1: Automated Deployment (Recommended)

```bash
# 1. Upload this entire folder to your server
scp -r device-sharing-deployment user@birdhouse.bb36.org:/tmp/

# 2. SSH into your server
ssh user@birdhouse.bb36.org

# 3. Run the deployment script
cd /tmp/device-sharing-deployment
chmod +x deploy.sh
sudo ./deploy.sh
```

### Option 2: Manual Deployment

```bash
# 1. SSH into your server
ssh user@birdhouse.bb36.org

# 2. Navigate to your project directory
cd /opt/birdhouse-viewer

# 3. Create backup
sudo cp -r /opt/birdhouse-viewer /opt/birdhouse-viewer-backup-$(date +%Y%m%d-%H%M%S)

# 4. Backup database
mysqldump -u root -p birdhouse > ~/birdhouse-backup-$(date +%Y%m%d-%H%M%S).sql

# 5. Copy updated backend files
sudo cp /tmp/device-sharing-deployment/drizzle/schema.ts drizzle/
sudo cp /tmp/device-sharing-deployment/server/db.ts server/
sudo cp /tmp/device-sharing-deployment/server/routers.ts server/
sudo cp /tmp/device-sharing-deployment/server/notifications.ts server/
sudo cp /tmp/device-sharing-deployment/server/videoRoutes.ts server/

# 6. Copy updated frontend files
sudo cp /tmp/device-sharing-deployment/client/src/components/ShareDeviceDialog.tsx client/src/components/
sudo cp /tmp/device-sharing-deployment/client/src/pages/Devices.tsx client/src/pages/

# 7. Copy documentation
sudo cp /tmp/device-sharing-deployment/DEVICE_SHARING.md .

# 8. Set proper ownership
sudo chown -R www-data:www-data /opt/birdhouse-viewer

# 9. Run database migration
cd /opt/birdhouse-viewer
pnpm db:push

# When prompted about ownerId column:
# Select: "~ userId › ownerId rename column"
# This preserves existing data

# 10. Rebuild the application
pnpm run build:google

# 11. Restart the backend service
sudo systemctl restart birdhouse-backend

# 12. Verify the service is running
sudo systemctl status birdhouse-backend
```

## Database Migration Interactive Prompt

When you run `pnpm db:push`, you'll see:

```
Is ownerId column in devices table created or renamed from another column?
❯ + ownerId          create column
  ~ userId › ownerId rename column
```

**IMPORTANT**: Select `~ userId › ownerId rename column` (press Down arrow, then Enter)

This ensures existing device ownership data is preserved.

## Verification Steps

After deployment, verify the feature is working:

### 1. Check Database Schema

```bash
mysql -u root -p birdhouse -e "DESCRIBE deviceShares;"
mysql -u root -p birdhouse -e "DESCRIBE devices;" | grep ownerId
```

You should see:
- `deviceShares` table with columns: id, deviceId, userId, role, sharedBy, sharedAt
- `devices` table has `ownerId` column (not `userId`)

### 2. Test in Browser

1. Open https://birdhouse.bb36.org
2. Sign in with your Google account
3. Navigate to Devices page
4. You should see:
   - "Owner" badge on your devices
   - Share button (share icon) on each device
5. Click the Share button
6. Enter an email address and test sharing
7. Sign in with the other account to verify they see the shared device

### 3. Check Logs

```bash
# Check for errors
sudo journalctl -u birdhouse-backend -n 100 --no-pager

# Should see no errors related to database or sharing
```

## Troubleshooting

### Migration Failed

**Error**: `Column 'userId' doesn't exist`

**Solution**: The migration already ran. Check if `ownerId` exists:
```bash
mysql -u root -p birdhouse -e "DESCRIBE devices;"
```

If `ownerId` exists, the migration was successful.

### Build Failed

**Error**: TypeScript errors about `userId`

**Solution**: 
1. Make sure all files were copied correctly
2. Clear build cache: `rm -rf dist/`
3. Rebuild: `pnpm run build:google`

### Service Won't Start

**Error**: Backend service fails to start

**Solution**:
```bash
# Check detailed logs
sudo journalctl -u birdhouse-backend -n 50 --no-pager

# Check if port 3000 is in use
sudo netstat -tlnp | grep 3000

# Restart service
sudo systemctl restart birdhouse-backend
```

### Share Button Not Appearing

**Possible causes**:
1. Frontend not rebuilt: Run `pnpm run build:google`
2. Browser cache: Hard refresh (Ctrl+Shift+R or Cmd+Shift+R)
3. Service not restarted: `sudo systemctl restart birdhouse-backend`

### "User with this email not found"

**Cause**: The user hasn't signed in yet

**Solution**: The person you're sharing with must sign in to the app at least once before you can share with them.

## Rollback Instructions

If you need to rollback to the previous version:

```bash
# 1. Use the automated rollback script
cd /tmp/device-sharing-deployment
chmod +x rollback.sh
sudo ./rollback.sh

# OR manually:

# 2. Stop the service
sudo systemctl stop birdhouse-backend

# 3. Restore backup
sudo rm -rf /opt/birdhouse-viewer
sudo cp -r /opt/birdhouse-viewer-backup-YYYYMMDD-HHMMSS /opt/birdhouse-viewer

# 4. Restore database
mysql -u root -p birdhouse < ~/birdhouse-backup-YYYYMMDD-HHMMSS.sql

# 5. Restart service
sudo systemctl start birdhouse-backend
```

## Testing Checklist

After deployment, test these scenarios:

- [ ] Owner can see "Owner" badge on their devices
- [ ] Owner can click Share button and see share dialog
- [ ] Owner can share device by entering email address
- [ ] Shared user sees device with "Shared" badge
- [ ] Shared user can view stream
- [ ] Shared user receives motion notifications
- [ ] Shared user cannot delete device
- [ ] Owner can see list of shared users
- [ ] Owner can remove shared user's access
- [ ] Removed user no longer sees the device

## Post-Deployment

### Update Documentation

Add a note to your main README or user guide about the new sharing feature.

### Notify Users

Inform your users about the new feature:
- Send an email or announcement
- Include link to DEVICE_SHARING.md documentation
- Explain how to share devices

### Monitor Usage

Check logs periodically for any sharing-related errors:
```bash
sudo journalctl -u birdhouse-backend -f | grep -i "shar"
```

## Support

For issues during deployment:
- Check service logs: `sudo journalctl -u birdhouse-backend -n 100`
- Check Apache logs: `sudo tail -f /var/log/apache2/error.log`
- Review database migration output
- Verify all files were copied correctly
- Check browser console for frontend errors

## Feature Documentation

See `DEVICE_SHARING.md` for complete feature documentation including:
- How to use device sharing
- Authorization model
- API endpoints
- Use cases and best practices
- Privacy and security considerations

## Summary

This deployment adds a powerful multi-user sharing feature while maintaining backward compatibility. All existing devices and data are preserved, and the migration is designed to be safe and reversible.

**Estimated deployment time**: 10-15 minutes
**Downtime**: ~2 minutes (during service restart)
**Risk level**: Low (reversible with rollback script)
