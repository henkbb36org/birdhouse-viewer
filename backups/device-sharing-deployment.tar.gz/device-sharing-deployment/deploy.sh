#!/bin/bash

# Device Sharing Feature - Automated Deployment Script
# This script deploys the device sharing feature to the Birdhouse Viewer application

set -e  # Exit on any error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Configuration
PROJECT_DIR="/opt/birdhouse-viewer"
BACKUP_DIR="/opt/birdhouse-viewer-backup-$(date +%Y%m%d-%H%M%S)"
DB_BACKUP="$HOME/birdhouse-backup-$(date +%Y%m%d-%H%M%S).sql"
SERVICE_NAME="birdhouse-backend"

echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}Device Sharing Feature Deployment${NC}"
echo -e "${GREEN}========================================${NC}"
echo ""

# Check if running as root or with sudo
if [ "$EUID" -ne 0 ]; then 
    echo -e "${RED}Error: This script must be run as root or with sudo${NC}"
    exit 1
fi

# Check if project directory exists
if [ ! -d "$PROJECT_DIR" ]; then
    echo -e "${RED}Error: Project directory $PROJECT_DIR not found${NC}"
    exit 1
fi

# Confirm deployment
echo -e "${YELLOW}This will deploy the device sharing feature to:${NC}"
echo "  Project: $PROJECT_DIR"
echo "  Service: $SERVICE_NAME"
echo ""
echo -e "${YELLOW}The following will be performed:${NC}"
echo "  1. Create backup of application files"
echo "  2. Create backup of database"
echo "  3. Copy updated files"
echo "  4. Run database migration"
echo "  5. Rebuild application"
echo "  6. Restart service"
echo ""
read -p "Continue with deployment? (y/N) " -n 1 -r
echo ""
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo -e "${YELLOW}Deployment cancelled${NC}"
    exit 0
fi

# Step 1: Backup application files
echo -e "${GREEN}[1/6] Creating backup of application files...${NC}"
cp -r "$PROJECT_DIR" "$BACKUP_DIR"
echo "  Backup created: $BACKUP_DIR"

# Step 2: Backup database
echo -e "${GREEN}[2/6] Creating backup of database...${NC}"
echo "  Please enter MySQL root password when prompted:"
mysqldump -u root -p birdhouse > "$DB_BACKUP" 2>/dev/null || {
    echo -e "${RED}  Database backup failed. Continue anyway? (y/N)${NC}"
    read -p "" -n 1 -r
    echo ""
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        echo -e "${RED}Deployment cancelled${NC}"
        exit 1
    fi
}
if [ -f "$DB_BACKUP" ]; then
    echo "  Database backup created: $DB_BACKUP"
fi

# Step 3: Copy updated files
echo -e "${GREEN}[3/6] Copying updated files...${NC}"

# Backend files
echo "  Copying backend files..."
cp drizzle/schema.ts "$PROJECT_DIR/drizzle/"
cp server/db.ts "$PROJECT_DIR/server/"
cp server/routers.ts "$PROJECT_DIR/server/"
cp server/notifications.ts "$PROJECT_DIR/server/"
cp server/videoRoutes.ts "$PROJECT_DIR/server/"

# Frontend files
echo "  Copying frontend files..."
cp client/src/components/ShareDeviceDialog.tsx "$PROJECT_DIR/client/src/components/"
cp client/src/pages/Devices.tsx "$PROJECT_DIR/client/src/pages/"

# Documentation
echo "  Copying documentation..."
cp DEVICE_SHARING.md "$PROJECT_DIR/"

# Set proper ownership
echo "  Setting file ownership..."
chown -R www-data:www-data "$PROJECT_DIR"

echo "  Files copied successfully"

# Step 4: Run database migration
echo -e "${GREEN}[4/6] Running database migration...${NC}"
echo ""
echo -e "${YELLOW}  IMPORTANT: When prompted about ownerId column:${NC}"
echo -e "${YELLOW}  Select: '~ userId › ownerId rename column'${NC}"
echo -e "${YELLOW}  (Press Down arrow, then Enter)${NC}"
echo ""
read -p "Press Enter to continue with migration..."

cd "$PROJECT_DIR"
sudo -u www-data pnpm db:push || {
    echo -e "${RED}  Migration failed!${NC}"
    echo -e "${YELLOW}  To rollback, run: sudo ./rollback.sh${NC}"
    exit 1
}

echo "  Migration completed successfully"

# Step 5: Rebuild application
echo -e "${GREEN}[5/6] Rebuilding application...${NC}"
cd "$PROJECT_DIR"
sudo -u www-data pnpm run build:google || {
    echo -e "${RED}  Build failed!${NC}"
    echo -e "${YELLOW}  To rollback, run: sudo ./rollback.sh${NC}"
    exit 1
}
echo "  Build completed successfully"

# Step 6: Restart service
echo -e "${GREEN}[6/6] Restarting service...${NC}"
systemctl restart "$SERVICE_NAME"
sleep 3

# Check service status
if systemctl is-active --quiet "$SERVICE_NAME"; then
    echo -e "  ${GREEN}Service restarted successfully${NC}"
else
    echo -e "  ${RED}Service failed to start!${NC}"
    echo "  Checking logs..."
    journalctl -u "$SERVICE_NAME" -n 20 --no-pager
    echo ""
    echo -e "${YELLOW}  To rollback, run: sudo ./rollback.sh${NC}"
    exit 1
fi

# Deployment complete
echo ""
echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}Deployment Completed Successfully!${NC}"
echo -e "${GREEN}========================================${NC}"
echo ""
echo -e "${GREEN}Backup locations:${NC}"
echo "  Application: $BACKUP_DIR"
if [ -f "$DB_BACKUP" ]; then
    echo "  Database: $DB_BACKUP"
fi
echo ""
echo -e "${GREEN}Next steps:${NC}"
echo "  1. Test the application at https://birdhouse.bb36.org"
echo "  2. Verify device sharing works (see DEVICE_SHARING.md)"
echo "  3. Check service logs: sudo journalctl -u $SERVICE_NAME -n 50"
echo ""
echo -e "${YELLOW}If you encounter issues:${NC}"
echo "  - Run: sudo ./rollback.sh"
echo "  - Check logs: sudo journalctl -u $SERVICE_NAME -n 100"
echo ""
echo -e "${GREEN}Feature documentation: $PROJECT_DIR/DEVICE_SHARING.md${NC}"
echo ""
