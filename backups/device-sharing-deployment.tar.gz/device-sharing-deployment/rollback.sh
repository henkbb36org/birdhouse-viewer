#!/bin/bash

# Device Sharing Feature - Rollback Script
# This script rolls back the device sharing deployment

set -e  # Exit on any error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Configuration
PROJECT_DIR="/opt/birdhouse-viewer"
SERVICE_NAME="birdhouse-backend"

echo -e "${YELLOW}========================================${NC}"
echo -e "${YELLOW}Device Sharing Feature Rollback${NC}"
echo -e "${YELLOW}========================================${NC}"
echo ""

# Check if running as root or with sudo
if [ "$EUID" -ne 0 ]; then 
    echo -e "${RED}Error: This script must be run as root or with sudo${NC}"
    exit 1
fi

# Find most recent backup
BACKUP_DIR=$(ls -td /opt/birdhouse-viewer-backup-* 2>/dev/null | head -1)
DB_BACKUP=$(ls -t $HOME/birdhouse-backup-*.sql 2>/dev/null | head -1)

if [ -z "$BACKUP_DIR" ]; then
    echo -e "${RED}Error: No backup directory found${NC}"
    echo "  Expected: /opt/birdhouse-viewer-backup-*"
    exit 1
fi

echo -e "${YELLOW}Found backups:${NC}"
echo "  Application: $BACKUP_DIR"
if [ -n "$DB_BACKUP" ]; then
    echo "  Database: $DB_BACKUP"
else
    echo -e "  Database: ${YELLOW}Not found${NC}"
fi
echo ""

# Confirm rollback
echo -e "${RED}WARNING: This will restore the application to the previous version${NC}"
echo -e "${RED}Any changes made after the backup will be lost${NC}"
echo ""
read -p "Continue with rollback? (y/N) " -n 1 -r
echo ""
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo -e "${YELLOW}Rollback cancelled${NC}"
    exit 0
fi

# Stop service
echo -e "${GREEN}[1/4] Stopping service...${NC}"
systemctl stop "$SERVICE_NAME"
echo "  Service stopped"

# Restore application files
echo -e "${GREEN}[2/4] Restoring application files...${NC}"
if [ -d "$PROJECT_DIR" ]; then
    rm -rf "$PROJECT_DIR"
fi
cp -r "$BACKUP_DIR" "$PROJECT_DIR"
chown -R www-data:www-data "$PROJECT_DIR"
echo "  Application files restored"

# Restore database
if [ -n "$DB_BACKUP" ] && [ -f "$DB_BACKUP" ]; then
    echo -e "${GREEN}[3/4] Restoring database...${NC}"
    echo "  Please enter MySQL root password when prompted:"
    mysql -u root -p birdhouse < "$DB_BACKUP" || {
        echo -e "${RED}  Database restore failed${NC}"
        echo -e "${YELLOW}  Application files have been restored, but database may be inconsistent${NC}"
    }
    echo "  Database restored"
else
    echo -e "${YELLOW}[3/4] Skipping database restore (no backup found)${NC}"
fi

# Restart service
echo -e "${GREEN}[4/4] Restarting service...${NC}"
systemctl start "$SERVICE_NAME"
sleep 3

# Check service status
if systemctl is-active --quiet "$SERVICE_NAME"; then
    echo -e "  ${GREEN}Service started successfully${NC}"
else
    echo -e "  ${RED}Service failed to start!${NC}"
    echo "  Checking logs..."
    journalctl -u "$SERVICE_NAME" -n 20 --no-pager
    exit 1
fi

# Rollback complete
echo ""
echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}Rollback Completed Successfully!${NC}"
echo -e "${GREEN}========================================${NC}"
echo ""
echo -e "${GREEN}Application restored to:${NC}"
echo "  $BACKUP_DIR"
echo ""
echo -e "${GREEN}Next steps:${NC}"
echo "  1. Test the application at https://birdhouse.bb36.org"
echo "  2. Verify functionality is working"
echo "  3. Check service logs: sudo journalctl -u $SERVICE_NAME -n 50"
echo ""
