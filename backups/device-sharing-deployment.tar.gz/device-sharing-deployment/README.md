# Device Sharing Feature - Deployment Package

This package contains everything needed to deploy the device sharing feature to your Birdhouse Viewer production server.

## Quick Start

```bash
# 1. Upload this folder to your server
scp -r device-sharing-deployment user@birdhouse.bb36.org:/tmp/

# 2. SSH into your server
ssh user@birdhouse.bb36.org

# 3. Run the deployment script
cd /tmp/device-sharing-deployment
chmod +x deploy.sh
sudo ./deploy.sh
```

## What's Included

### Files

- **Backend Updates:**
  - `drizzle/schema.ts` - Database schema with deviceShares table
  - `server/db.ts` - Sharing queries and authorization helpers
  - `server/routers.ts` - Sharing API procedures
  - `server/notifications.ts` - Multi-user notification support
  - `server/videoRoutes.ts` - Updated video authorization

- **Frontend Updates:**
  - `client/src/components/ShareDeviceDialog.tsx` - Share management UI
  - `client/src/pages/Devices.tsx` - Updated devices page with sharing

- **Documentation:**
  - `DEVICE_SHARING.md` - Complete feature documentation
  - `DEPLOY_DEVICE_SHARING.md` - Detailed deployment guide
  - `README.md` - This file

- **Scripts:**
  - `deploy.sh` - Automated deployment script
  - `rollback.sh` - Rollback script if needed

### Database Changes

⚠️ **This update includes database schema changes:**

1. **Column rename**: `devices.userId` → `devices.ownerId` (preserves data)
2. **New table**: `deviceShares` (for sharing relationships)

The migration is **safe** and **reversible**. All existing data is preserved.

## Feature Overview

**Device Sharing** allows multiple users to access the same birdhouse camera:

- ✅ Share devices by email address
- ✅ Owner/Viewer role system
- ✅ All shared users receive motion notifications
- ✅ Visual badges showing ownership status
- ✅ Easy share management dialog
- ✅ Proper authorization on all operations

## Deployment Options

### Option 1: Automated (Recommended)

Use the included `deploy.sh` script:

```bash
sudo ./deploy.sh
```

The script will:
1. Create backups (files + database)
2. Copy updated files
3. Run database migration
4. Rebuild application
5. Restart service

**Time**: ~10 minutes  
**Downtime**: ~2 minutes

### Option 2: Manual

Follow the detailed steps in `DEPLOY_DEVICE_SHARING.md`.

## Important Notes

### Database Migration Prompt

When running the migration, you'll see:

```
Is ownerId column in devices table created or renamed from another column?
❯ + ownerId          create column
  ~ userId › ownerId rename column
```

**Select**: `~ userId › ownerId rename column` (press Down arrow, then Enter)

This preserves your existing device ownership data.

### Rollback

If something goes wrong, use the rollback script:

```bash
sudo ./rollback.sh
```

This will restore both application files and database from the backups created during deployment.

## Testing After Deployment

1. **Sign in** to https://birdhouse.bb36.org
2. **Navigate** to Devices page
3. **Verify** you see "Owner" badges on your devices
4. **Click** the Share button (share icon)
5. **Enter** an email address and test sharing
6. **Sign in** with the other account to verify they see the shared device

## Documentation

- **Feature Guide**: `DEVICE_SHARING.md` - How to use device sharing
- **Deployment Guide**: `DEPLOY_DEVICE_SHARING.md` - Detailed deployment instructions
- **Troubleshooting**: See `DEPLOY_DEVICE_SHARING.md` for common issues

## Support

If you encounter issues:

1. Check service logs: `sudo journalctl -u birdhouse-backend -n 100`
2. Review deployment output for errors
3. Check database migration completed: `mysql -u root -p birdhouse -e "DESCRIBE deviceShares;"`
4. Try rollback if needed: `sudo ./rollback.sh`

## File Structure

```
device-sharing-deployment/
├── README.md                          # This file
├── DEPLOY_DEVICE_SHARING.md          # Detailed deployment guide
├── DEVICE_SHARING.md                 # Feature documentation
├── deploy.sh                         # Automated deployment script
├── rollback.sh                       # Rollback script
├── drizzle/
│   └── schema.ts                     # Updated database schema
├── server/
│   ├── db.ts                         # Database queries
│   ├── routers.ts                    # API procedures
│   ├── notifications.ts              # Notification system
│   └── videoRoutes.ts                # Video authorization
└── client/
    └── src/
        ├── components/
        │   └── ShareDeviceDialog.tsx # Share management UI
        └── pages/
            └── Devices.tsx           # Updated devices page
```

## Requirements

- Node.js v22.15.0+
- pnpm package manager
- MySQL database
- Existing Birdhouse Viewer installation
- Root/sudo access

## Estimated Time

- **Automated deployment**: 10-15 minutes
- **Manual deployment**: 20-30 minutes
- **Downtime**: ~2 minutes (during service restart)

## Safety

- ✅ Creates automatic backups
- ✅ Preserves all existing data
- ✅ Reversible with rollback script
- ✅ Low risk deployment

## Questions?

See the detailed documentation:
- `DEPLOY_DEVICE_SHARING.md` - Deployment troubleshooting
- `DEVICE_SHARING.md` - Feature usage and best practices
